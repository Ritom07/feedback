

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#00FF33">ONLINE FACULTY FEEDBACK SYSTEM</font> </h1>
                
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row" style="margin-bottom:50px;margin-left:50px">
           
               <P style="color:slateblue">ECHO SURVEY - A Online Feedback System 
               The Online Feedback System is a web-based application designed to facilitate the collection, management, and analysis of feedback from users such as students, employees, or customers. It replaces traditional paper-based feedback methods, offering a more efficient, organized, and secure way to gather valuable insights.
                </P> 
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
     