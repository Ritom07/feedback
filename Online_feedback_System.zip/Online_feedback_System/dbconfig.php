<?php
$conn=mysqli_connect("localhost","root","","database")or die(mysqli_error());
?>